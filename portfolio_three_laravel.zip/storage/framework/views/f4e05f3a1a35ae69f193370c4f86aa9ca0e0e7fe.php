<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/form.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Login</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<body>
    <?php if(session('success')): ?>
    <div class="centre-container centre-container__info_box">
        <div class="info_box">
            <div>Success. You are now logged in!</div>
            <div>Click <a href="<?php echo e(route('home')); ?>">here</a> to go back to the homepage.</div>
        </div>
        <!-- SCRIPT TAG to delete the incumbent CV form localStorage data -->
        <script type="text/javascript">
            localStorage.clear();
        </script>
    </div>
    <?php else: ?>
    <div class="centre-container centre-container--login_form">
        <form action="<?php echo e(route('createAccount')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <h1>Login</h1>
            <?php if(session('error')): ?>
            <div class="error_msg">Wrong account details. Try again.</div>
            <?php endif; ?>
            <div class="form__label_container">
                <label for="form_email">Email:</label>
                <div class="form__sub_label">Need an account? <a href="<?php echo e(route('signup')); ?>">Sign up</a></div>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error_msg"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" name="email" id="form_email" class="form__input" value="<?php if(!empty(old('email'))): ?><?php echo e(old('email')); ?><?php else: ?><?php echo e(session('email')); ?><?php endif; ?>" />
            <div class="form__label_container">
                <label for="form_password">Password:</label>
                <div class="form__sub_label form__sub_label--show_hide"><i class="fa-solid fa-eye"></i>Show</div>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error_msg"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" name="password" id="form_password" class="form__input" />
            <div class="form__checkbox_container">
                <label for="form_remember">Remember me: </label>
                <input type="checkbox" name="remember" id="form_remember">
            </div>
            <input type="submit" class="form__submit" value="Login" />
            <a href="<?php echo e(route('requestToChangePassword')); ?>" class="form__forgot_password_msg">Forgot Password?</a>
        </form>
    </div>
    <!-- FORM SCRIPT -->
    <script src="<?php echo e(asset('public/js/form.js')); ?>"></script>
    <?php endif; ?>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/login.blade.php ENDPATH**/ ?>