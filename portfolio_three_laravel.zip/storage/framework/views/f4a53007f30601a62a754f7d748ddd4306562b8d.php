<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/form.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Logout</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<body>
    <div class="centre-container centre-container__info_box">
        <div class="info_box">
            <div>Success. You have been logged out!</div>
            <div>Click <a href="<?php echo e(route('home')); ?>">here</a> to go back to the homepage.</div>
        </div>
    </div>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/logout.blade.php ENDPATH**/ ?>