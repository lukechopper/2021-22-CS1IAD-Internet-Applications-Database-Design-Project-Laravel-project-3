<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/view-cv.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>View CV</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<body>
    <section class="about container" id="about">
        <h1 class="title about__title">About</h1>
        <div class="underline about__title-underline"></div>
        <h1 class="about__sub-title"><?php echo e($name); ?></h1>
        <hr class="about__hr" />
        <div class="about__main-section">
            <div class="about__main-section-col-1">
                <h2 class="about__main-section-header">Profile:</h2>
                <p>
                    <?php echo e($profile); ?>

                </p>
            </div>
            <div class="about__main-section-col-2">
                <div class="about__main-section-info-desc about__main-section-info-desc--top_padding">
                    <h2 class="about__main-section-header">Email:</h2>
                    <a href="<?php echo e('mailto:'.$email); ?>">
                        <p class="inline"><?php echo e($email); ?></p>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php if(count($formattedEducationInfo)): ?>
    <section class="education container" id="education">
        <h1 class="title education__title">Education</h1>
        <div class="underline education__title-underline"></div>
        <?php for($i=0; $i < count($formattedEducationInfo); $i++): ?>
        <div class="general-list-item">
            <h2><?php echo e($formattedEducationInfo[$i][0]); ?></h2>
            <em><?php echo e($formattedEducationInfo[$i][1]); ?></em>
        </div>
        <p><?php echo e($formattedEducationInfo[$i][2]); ?></p>
        <?php endfor; ?>
    </section>
    <?php endif; ?>
    <?php if(count($formattedProgrammingInfo)): ?>
    <section class="programming container">
        <h1 class="title programming__title">Programming Languages</h1>
        <div class="underline programming__title-underline"></div>
        <?php for($i=0; $i < count($formattedProgrammingInfo); $i++): ?>
        <div class="general-list-item">
            <h2><?php echo e($formattedProgrammingInfo[$i][0]); ?></h2>
            <em><?php echo e($formattedProgrammingInfo[$i][1]); ?></em>
        </div>
        <p><?php echo e($formattedProgrammingInfo[$i][2]); ?></p>
        <?php endfor; ?>
    </section>
    <?php endif; ?>
    <?php if(count($formattedUrlLinksInfo)): ?>
    <section class="url container">
        <h1 class="title url__title">URL Links</h1>
        <div class="underline url__title-underline"></div>
        <?php for($i=0; $i < count($formattedUrlLinksInfo); $i++): ?>
        <div class="general-list-item">
            <h2><?php echo e($formattedUrlLinksInfo[$i][0]); ?></h2>
        </div>
        <p><a href="<?php echo e($formattedUrlLinksInfo[$i][1]); ?>" class="url__link" target="_blank"><?php echo e($formattedUrlLinksInfo[$i][1]); ?></a></p>
        <?php endfor; ?>
    </section>
    <?php endif; ?>
    <footer></footer>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/cv/view.blade.php ENDPATH**/ ?>