<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/create-cv.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Update CV</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<script type="text/javascript">
    let canSkipWarningMessage = false;
</script>

<body>
<div class="container container--create_cv">
        <form action="<?php echo e(route('put.update.cv')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form__container form__container--full form__container--top">
                <h1 class="form__header">Update CV</h1>
                <?php if(session('error')): ?>
                    <div class="error_msg"><?php echo e(session('error')); ?></div>
                <?php elseif(session('success')): ?>
                    <div class="success_msg"><?php echo e(session('success')); ?></div>
                    <?php if(session('success') === 'Success! The CV has been updated.'): ?>
                    <div class="success_msg success_msg--second_line">Click <a href="<?php echo e(route('viewCV', auth()->user()->cv->id)); ?>" class="bold">here</a> to view it.</div>
                    <?php endif; ?>
                <?php else: ?>
                <div class="success_msg">Click <a href="<?php echo e(route('viewCV', auth()->user()->cv->id)); ?>" class="bold">here</a> to view it.</div>
                <?php endif; ?>
                <?php if(session('error') || session('success')): ?>
                <!-- SCRIPT TAG -->
                <script type="text/javascript">
                    localStorage.setItem('edit_cv_done_yet', 'no');
                    canSkipWarningMessage = true;
                </script>
                <?php endif; ?>
            </div>
            <input type="hidden" name="delete_cv" id="delete_cv_hidden_input" value="no" >
            <div class="form__container form__container--full">
                <div class="form__delete_cv" id="form__delete_cv"><i class="fa-solid fa-circle-minus"></i>Click Here To Delete CV</div>
            </div>
            <div class="form__container">
                <label for="form_first_name">First Name:</label>
                <?php if(count($errors->get('last_name')) && !count($errors->get('first_name'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('first_name'))): ?>
                <div class="error_msg"><?php echo e($errors->get('first_name')[0]); ?></div>
                <?php endif; ?>
                <input type="text" name="first_name" id="form_first_name" class="form__input" value="<?php if(!empty($formattedCVStaticInfo['first_name'])): ?><?php echo e($formattedCVStaticInfo['first_name']); ?> <?php endif; ?>">
            </div>
            <div class="form__container">
                <label for="form_last_name">Last Name:</label>
                <?php if(count($errors->get('first_name')) && !count($errors->get('last_name'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('last_name'))): ?>
                <div class="error_msg"><?php echo e($errors->get('last_name')[0]); ?></div>
                <?php endif; ?>
                <input type="text" name="last_name" id="form_last_name" class="form__input" value="<?php if(!empty($formattedCVStaticInfo['last_name'])): ?><?php echo e($formattedCVStaticInfo['last_name']); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--full">
                <label for="form_profile">Profile:</label>
                <?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error_msg"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <textarea name="profile" id="form_profile" class="form__input form__input--textarea"><?php if(!empty($formattedCVStaticInfo['profile'])): ?><?php echo e($formattedCVStaticInfo['profile']); ?> <?php endif; ?></textarea>
            <!-- OPEN EDUCATION SECTION -->
            <div class="form__container form__container--full">
                <label class="bold">Education</label>
            </div>
            <div class="form__container form__container--full form__container--5px_top_margin">
                <div class="form__add_new_item" id="form__add_new_education_item"><i class="fa-solid fa-circle-plus"></i>Add New Item</div>
            </div>
            <?php for($i=0; $i < count($formattedEducationInfo); $i++): ?>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_education_'.$i); ?>" open_info="<?php echo e('form_education_'.$i); ?>" >
                <label for="<?php echo e('form_education_'.$i.'_name'); ?>">Name:</label>
                <?php if(preg_match("/.*contain letters, numbers, dashes and underscores.*/i",count($errors->get('education_'.$i.'_duration')) ? $errors->get('education_'.$i.'_duration')[0] : '')): ?>
                <div class="error_padding" ></div>
                <?php endif; ?>
                <?php if(count($errors->get('education_'.$i.'_duration')) && !count($errors->get('education_'.$i.'_name'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('education_'.$i.'_name'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The education [0-9]+ name/i",'This education name',$errors->get('education_'.$i.'_name')[0])); ?></div>
                <?php endif; ?>
                <input type="text" name="<?php echo e('education_'.$i.'_name'); ?>" id="<?php echo e('form_education_'.$i.'_name'); ?>" class="form__input" value="<?php if(!empty($formattedEducationInfo[$i][0])): ?><?php echo e($formattedEducationInfo[$i][0]); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_education_'.$i); ?>">
                <label for="<?php echo e('form_education_'.$i.'_duration'); ?>">Duration:</label>
                <?php if(count($errors->get('education_'.$i.'_name')) && !count($errors->get('education_'.$i.'_duration'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('education_'.$i.'_duration'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The education [0-9]+ duration/i",'This education duration',$errors->get('education_'.$i.'_duration')[0])); ?></div>
                <?php endif; ?>
                <input type="text" name="<?php echo e('education_'.$i.'_duration'); ?>" id="<?php echo e('form_education_'.$i.'_duration'); ?>" class="form__input" value="<?php if(!empty($formattedEducationInfo[$i][1])): ?><?php echo e($formattedEducationInfo[$i][1]); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--full form__container--less_top_margin" delete_info="<?php echo e('form_education_'.$i); ?>">
                <label for="<?php echo e('form_education_'.$i.'_description'); ?>">Description:</label>
                <div class="form__text_box_then_delete_icon">
                    <div class="form__textarea_container">
                    <?php if(count($errors->get('education_'.$i.'_description'))): ?>
                    <div class="error_msg"><?php echo e(preg_replace("/The education [0-9]+ description/i",'This education description',$errors->get('education_'.$i.'_description')[0])); ?></div>
                    <?php endif; ?>
                    <textarea name="<?php echo e('education_'.$i.'_description'); ?>" id="<?php echo e('form_education_'.$i.'_description'); ?>" class="form__input form__input--smaller_textarea"><?php if(!empty($formattedEducationInfo[$i][2])): ?><?php echo e($formattedEducationInfo[$i][2]); ?> <?php endif; ?></textarea>
                    </div>
                    <div class="form__spacing_between_text_box_and_delete_icon"></div>
                    <i class="fa-solid fa-trash-can" delete_info="<?php echo e('form_education_'.$i); ?>"></i>
                </div>
            </div>
            <?php endfor; ?>
            <!-- END EDUCATION SECTION -->
            <!-- OPEN KEY PROGRAMMING LANGUAGES SECTION -->
            <div class="form__container form__container--full" id="form__begin_key_programming_languages_section">
                <label class="bold">Key Programming Languages</label>
            </div>
            <div class="form__container form__container--full form__container--5px_top_margin">
                <div class="form__add_new_item" id="form__add_new_programming_language"><i class="fa-solid fa-circle-plus"></i>Add New Item</div>
            </div>
            <?php for($i=0; $i < count($formattedProgrammingInfo); $i++): ?>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_key_programming_language_'.$i); ?>" open_info="<?php echo e('form_key_programming_language_'.$i); ?>">
                <label for="<?php echo e('form_key_programming_language_'.$i.'_name'); ?>">Name:</label>
                <?php if(preg_match("/.*contain letters, numbers, dashes and underscores.*/i",count($errors->get('key_programming_language_'.$i.'_duration')) ? $errors->get('key_programming_language_'.$i.'_duration')[0] : '')): ?>
                <div class="error_padding" ></div>
                <?php endif; ?>
                <?php if(count($errors->get('key_programming_language_'.$i.'_duration')) && !count($errors->get('key_programming_language_'.$i.'_name'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('key_programming_language_'.$i.'_name'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The key programming language [0-9]+/i",'This language',$errors->get('key_programming_language_'.$i.'_name')[0])); ?></div>
                <?php endif; ?>
                <input type="text" name="<?php echo e('key_programming_language_'.$i.'_name'); ?>" id="<?php echo e('form_key_programming_language_'.$i.'_name'); ?>" class="form__input" value="<?php if(!empty($formattedProgrammingInfo[$i][0])): ?><?php echo e($formattedProgrammingInfo[$i][0]); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_key_programming_language_'.$i); ?>">
                <label for="<?php echo e('form_key_programming_language_'.$i.'_duration'); ?>">Duration:</label>
                <?php if(count($errors->get('key_programming_language_'.$i.'_name')) && !count($errors->get('key_programming_language_'.$i.'_duration'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('key_programming_language_'.$i.'_duration'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The key programming language [0-9]+/i",'This language',$errors->get('key_programming_language_'.$i.'_duration')[0])); ?></div>
                <?php endif; ?>
                <input type="text" name="<?php echo e('key_programming_language_'.$i.'_duration'); ?>" id="<?php echo e('form_key_programming_language_'.$i.'_duration'); ?>" class="form__input" value="<?php if(!empty($formattedProgrammingInfo[$i][1])): ?><?php echo e($formattedProgrammingInfo[$i][1]); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--full form__container--less_top_margin" delete_info="<?php echo e('form_key_programming_language_'.$i); ?>">
                <label for="<?php echo e('form_key_programming_language_'.$i.'_description'); ?>">Description:</label>
                <div class="form__text_box_then_delete_icon">
                    <div class="form__textarea_container">
                    <?php if(count($errors->get('key_programming_language_'.$i.'_description'))): ?>
                    <div class="error_msg"><?php echo e(preg_replace("/The key programming language [0-9]+/i",'This language',$errors->get('key_programming_language_'.$i.'_description')[0])); ?></div>
                    <?php endif; ?>
                    <textarea name="<?php echo e('key_programming_language_'.$i.'_description'); ?>" id="<?php echo e('form_key_programming_language_'.$i.'_description'); ?>" class="form__input form__input--smaller_textarea"><?php if(!empty($formattedProgrammingInfo[$i][2])): ?><?php echo e($formattedProgrammingInfo[$i][2]); ?> <?php endif; ?></textarea>
                    </div>
                    <div class="form__spacing_between_text_box_and_delete_icon"></div>
                    <i class="fa-solid fa-trash-can" delete_info="<?php echo e('form_key_programming_language_'.$i); ?>"></i>
                </div>
            </div>
            <?php endfor; ?>
            <!-- END KEY PROGRAMMING LANGUAGES SECTION -->
            <!-- OPEN URL LINKS SECTION -->
            <div class="form__container form__container--full" id="form__begin_url_links_section">
                <label class="bold">URL Links</label>
            </div>
            <div class="form__container form__container--full form__container--5px_top_margin">
                <div class="form__add_new_item" id="form__add_new_url_link"><i class="fa-solid fa-circle-plus"></i>Add New Item</div>
            </div>
            <?php for($i=0; $i < count($formattedUrlLinksInfo); $i++): ?>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_url_link_'.$i); ?>" open_info="<?php echo e('form_url_link_'.$i); ?>">
                <label for="<?php echo e('form_url_link_'.$i.'_title'); ?>">Title:</label>
                <?php if(count($errors->get('url_link_'.$i.'_url')) && !count($errors->get('url_link_'.$i.'_title'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('url_link_'.$i.'_title'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The url link [0-9]+/i",'This url link',$errors->get('url_link_'.$i.'_title')[0])); ?></div>
                <?php endif; ?>
                <input type="text" name="<?php echo e('url_link_'.$i.'_title'); ?>" id="<?php echo e('form_url_link_'.$i.'_title'); ?>" class="form__input" value="<?php if(!empty($formattedUrlLinksInfo[$i][0])): ?><?php echo e($formattedUrlLinksInfo[$i][0]); ?> <?php endif; ?>">
            </div>
            <div class="form__container form__container--less_top_margin" delete_info="<?php echo e('form_url_link_'.$i); ?>">
                <label for="<?php echo e('form_url_link_'.$i.'_url'); ?>">URL:</label>
                <?php if(count($errors->get('url_link_'.$i.'_title')) && !count($errors->get('url_link_'.$i.'_url'))): ?>
                <div class="error_padding" ></div>
                <?php elseif(count($errors->get('url_link_'.$i.'_url'))): ?>
                <div class="error_msg"><?php echo e(preg_replace("/The url link [0-9]+/i",'This url link',$errors->get('url_link_'.$i.'_url')[0])); ?></div>
                <?php endif; ?>
                <div class="form__text_box_then_delete_icon">
                    <input type="text" name="<?php echo e('url_link_'.$i.'_url'); ?>" id="<?php echo e('form_url_link_'.$i.'_url'); ?>" class="form__input" value="<?php if(!empty($formattedUrlLinksInfo[$i][1])): ?><?php echo e($formattedUrlLinksInfo[$i][1]); ?> <?php endif; ?>">
                    <div class="form__spacing_between_text_box_and_delete_icon"></div>
                    <i class="fa-solid fa-trash-can" delete_info="<?php echo e('form_url_link_'.$i); ?>"></i>
                </div>
            </div>
            <?php endfor; ?>
            <!-- END URL LINKS SECTION -->
            <div class="form__container form__container--full" id="form__submit_section">
                <input type="submit" class="form__submit" value="Update">
            </div>
        </form>
    </div>
    <!-- LARAVEL SCRIPT -->
    <script type="text/javascript">
        let errorObj = { };
        <?php if(count($errors->get('first_name'))): ?>
        errorObj["first_name"] = "<?php echo e($errors->get('first_name')[0]); ?>";
        <?php endif; ?>

        <?php for($i=0;$i<count($errors->all());$i++): ?>
        <?php if(!empty($errors->keys()[$i])): ?>
        errorObj["<?php echo e($errors->keys()[$i]); ?>"] = "<?php echo e($errors->all()[$i]); ?>";
        <?php endif; ?>
        <?php endfor; ?>

        let phpEducationItems = <?php echo e(!empty($formattedEducationInfo[0][0]) ? count($formattedEducationInfo)-1 : 0); ?>;
        let phpProgrammingLanguagesItems = <?php echo e(!empty($formattedProgrammingInfo[0][0]) ? count($formattedProgrammingInfo)-1 : 0); ?>;
        let phpUrlLinksItems = <?php echo e(!empty($formattedUrlLinksInfo[0][0]) ? count($formattedUrlLinksInfo)-1 : 0); ?>;

    </script>
    <!-- Create CV SCRIPT -->
    <script src="<?php echo e(asset('public/js/update_cv.js')); ?>"></script>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/cv/update.blade.php ENDPATH**/ ?>