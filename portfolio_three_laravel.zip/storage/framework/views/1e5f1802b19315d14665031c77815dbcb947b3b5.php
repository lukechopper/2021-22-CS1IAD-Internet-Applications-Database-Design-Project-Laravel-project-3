<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>