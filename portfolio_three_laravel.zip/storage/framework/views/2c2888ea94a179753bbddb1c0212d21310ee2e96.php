<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- FAVICON HERE -->
    <link rel="shortcut icon" href="<?php echo e(asset('public/img/cv-icon.png')); ?>" type="image/png">
    <!-- Global CSS file, used for the header, here -->
    <link rel="stylesheet" href="<?php echo e(asset('public/css/global.css')); ?>">
    <!-- Include CSS analagous to a specific view here -->
    <?php echo $__env->yieldContent('css'); ?>
    <!-- Include JQuery here -->
    <script src="<?php echo e(asset('public/js/jQuery/jQuery.js')); ?>"></script>
    <!-- Include gsap here -->
    <script src="<?php echo e(asset('public/js/gsap/gsap.min.js')); ?>"></script>
    <!-- Font Awesome here -->
    <link rel="stylesheet" href="<?php echo e(asset('public/css/font_awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/font_awesome/css/fontawesome.min.css')); ?>">

    <?php echo $__env->yieldContent('title'); ?>
</head>
<header id="header">
    <section class="header__left-section">
        <a href="<?php echo e(route('home')); ?>">
            <h1 class="header__title">Aston CV</h1>
        </a>
        <ul class="header__options_small">
            <li id="open_header_submenu">Menu <i class="fa-solid fa-caret-down"></i></li>
        </ul>
        <ul class="header__options <?php if(auth()->guard()->guest()): ?> header__options--no_auth <?php endif; ?>">
            <i class="fa-solid fa-xmark" id="header__dropdown_close"></i>
            <a href="<?php echo e(route('home')); ?>">
                <li class="header__first_option">Home</li>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->cv): ?>
                <a href="<?php echo e(route('update.cv')); ?>"><li>My CV</li></a>
                <?php else: ?>
                <a href="<?php echo e(route('create.cv')); ?>"><li>Create CV</li></a>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </section>
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('logout')); ?>" class="header__account_btn">Logout</a>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
    <a href="<?php echo e(route('login')); ?>" class="header__account_btn">Login</a>
    <?php endif; ?>
</header>
<!-- HEADER SCRIPT -->
<script src="<?php echo e(asset('public/js/header.js')); ?>"></script>
<?php echo $__env->yieldContent('body'); ?>
<?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/partials/header.blade.php ENDPATH**/ ?>