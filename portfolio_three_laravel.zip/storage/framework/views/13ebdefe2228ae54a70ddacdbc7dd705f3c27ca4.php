<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/form.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Change Password</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<body>
    <div class="centre-container centre-container__request_to_change_password">
        <form action="<?php echo e(route('forgotPassword')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <h1>Request To Change Password</h1>
            <?php if(session('success')): ?>
            <div class="success_msg"><?php echo e(session('success')); ?></div>
            <?php elseif(session('error')): ?>
            <div class="error_msg"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <label for="form_email">Email:</label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error_msg"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" name="email" id="form_email" class="form__input" value="<?php echo e(old('email')); ?>" />
            <input type="submit" class="form__submit" value="Send Email" />
        </form>
    </div>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\portfolio_three_laravel\resources\views/requestToChangePassword.blade.php ENDPATH**/ ?>